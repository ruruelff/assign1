// This is an abstract class named "Computer." Abstract classes cannot be instantiated, and they often serve as a base for other classes.
public abstract class Computer {

    // These are abstract methods that must be implemented by any concrete subclass.
    // They represent the characteristics of a computer: RAM, HDD, and CPU.
    public abstract String getRAM();
    public abstract String getHDD();
    public abstract String getCPU();

    // This is an overridden method from the Object class, providing a custom string representation of a Computer object.
    @Override
    public String toString(){
        // It returns a formatted string containing information about RAM, HDD, and CPU.
        return "RAM= "+this.getRAM()+", HDD="+this.getHDD()+", CPU="+this.getCPU();
    }
}

